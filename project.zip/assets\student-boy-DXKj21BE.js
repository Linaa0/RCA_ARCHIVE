const s="/assets/student-girl-D-KAOh0x.png",t="/assets/student-boy-lyu9A-Ky.png";export{s as a,t as s};
